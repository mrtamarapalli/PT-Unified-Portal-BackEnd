import boto3
from botocore.exceptions import ClientError


#######################################################
# Get secret from AWS Secret Manager
#######################################################
def get_secret(secret_name=None, region_name=None):
    secret_name = '566692369023'
    region_name = "us-east-1"
    session = boto3.session.Session()
    client = session.client(
            service_name='secretsmanager',
            region_name=region_name or session.region_name,
        )
    try:
        response = client.get_secret_value(SecretId=secret_name)
    
        if 'SecretString' in response:
            secret = response['SecretString']
        else:
            # If the secret is stored as binary, you may need additional processing
            secret = response['SecretBinary']
        return secret
    except ClientError as e:
        print("except")
        print(e.response)
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e