import boto3, json
from secrets import get_secret

TABLENAME = "GITHUB_DATA_TABLE"


secrets = get_secret()
secrets = json.loads(secrets)

dynamodb = boto3.client('dynamodb',
               'us-east-1',
              aws_access_key_id= secrets['aws_access_key_id'],
              aws_secret_access_key=secrets['aws_secret_access_key'])
       
       
#######################################################
# Read the dynamoDB 
#######################################################
def read_dynamodb(tablename, condition):
    print(f"tablename: {tablename}")
    print(f"condition: {condition}")
    obj = dynamodb.get_item(TableName = tablename, Key= {"email_id": {"S": "dawerfilpe@oktaidp.com"}})
    return obj

#######################################################
# Scan the dynamoDB Table based on filter expression
# return the first item from the object
#######################################################
def scan_dynamodb(tablename, filter_expression, expression_value, expression_name = {}):
    obj = dynamodb.scan(
        TableName = tablename, 
        FilterExpression = filter_expression, 
        ExpressionAttributeValues=expression_value,
        ExpressionAttributeNames=expression_name
    )
    return obj["Items"][0]