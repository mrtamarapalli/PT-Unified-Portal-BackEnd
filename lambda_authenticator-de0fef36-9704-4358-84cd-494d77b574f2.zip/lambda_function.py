"""
Copyright 2015-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

     http://aws.amazon.com/apache2.0/

or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
"""
from __future__ import print_function
import json
import re, time
import urllib.request
from jose import jwk, jwt
from jose.utils import base64url_decode
from dynamoutils import  *

region = 'us-east-1'
userpool_id = 'us-east-1_0YRI34cxi'
app_client_id = '4rcj9d5gvssngt6t0bu2llg0dq'
keys_url = 'https://cognito-idp.{}.amazonaws.com/{}/.well-known/jwks.json'.format(region, userpool_id)
# instead of re-downloading the public keys every time
# we download them only on cold start
# https://aws.amazon.com/blogs/compute/container-reuse-in-lambda/
with urllib.request.urlopen(keys_url) as f:
  response = f.read()
keys = json.loads(response.decode('utf-8'))['keys']


# DynamoDB Tables
USER_MGMTTABLE = "usermanagement"
ROLE_TABLE = "roletable"
API_ROLE_TABLE = "api_rolemapping_table"
API_TABLE_MASTERDB = "api_table_masterdata"


def lambda_handler(event, context):
    print("Generating Policy.....")
    print(event)
    principalId = "dawerfilpe@oktaidp.com"
    token = event["headers"]["token"]
    
    request_context = event.get("requestContext", {})
    
    awsAccountId = request_context.get("accountId", "")
    
    # Generate Policy 
    policy = AuthPolicy(principalId, awsAccountId)
    policy.restApiId = request_context.get("apiId", "")
    policy.region = "us-east-1"
    policy.stage = request_context.get("stage", "")
    
    
    if (auth_data := check_token(token))["is_authorize"]:
        print(f"Auth Data: {auth_data}")
        user_roles = check_user_and_role(auth_data.get("email"))
        if user_roles.get("is_valid"):
            apiid_role = check_apiid_and_role(api_id = request_context.get("apiId"), role_id = user_roles["role_id"])
            if apiid_role.get("is_valid"):
                policy.allowAllMethods()
            else:
                policy.denyAllMethods()
        else:
            policy.denyAllMethods()
    else:
        policy.denyAllMethods()
    
    """policy.allowMethod(HttpVerb.GET, "/pets/*")"""
    
    authResponse = policy.build()
    
    context = {
        "key": "value",  # $context.authorizer.key -> value
        "number": 1,
        "bool": True,
    }


    authResponse["context"] = context
    return authResponse



#####################################################################
# Validate the token and extract the details through claims
#####################################################################
def check_token(token):
    
    # get the kid from the headers prior to verification
    headers = jwt.get_unverified_headers(token)
    kid = headers['kid']
    # search for the kid in the downloaded public keys
    key_index = -1
    for i in range(len(keys)):
        if kid == keys[i]['kid']:
            key_index = i
            break
    if key_index == -1:
        print('Public key not found in jwks.json')
        return {"is_authorize": False}
    # construct the public key
    public_key = jwk.construct(keys[key_index])
    # get the last two sections of the token,
    # message and signature (encoded in base64)
    message, encoded_signature = str(token).rsplit('.', 1)
    # decode the signature
    decoded_signature = base64url_decode(encoded_signature.encode('utf-8'))

    if not public_key.verify(message.encode("utf8"), decoded_signature):
        print('Signature verification failed')
        return {"is_authorize": False}
    print('Signature successfully verified')
    # since we passed the verification, we can now safely
    # use the unverified claims
    claims = jwt.get_unverified_claims(token)
    # additionally we can verify the token expiration
    print(f"Claims: {claims}")
    if time.time() > claims['exp']:
        print('Token is expired')
        return {"is_authorize": False, "email": claims.get("email")}
    # and the Audience  (use claims['client_id'] if verifying an access token)
    if claims['aud'] != app_client_id:
        print('Token was not issued for this audience')
        return {"is_authorize": False, "email": claims.get("email")}
    return {"email": claims.get("email"), "is_authorize": True}
    

#######################################################
# Validate if User and Role using Email 
#######################################################
def check_user_and_role(email):
    try:
        print(f"Email: {email}")
        user_obj = scan_dynamodb(tablename=USER_MGMTTABLE, 
        filter_expression = "email_id = :email_id AND #status = :status", 
        expression_value = {":email_id": {"S": email}, ":status": {"S": "active"}},
        expression_name = {"#status": "status"})
        
        print(f"user_obj: {user_obj}")
        
        if user_obj:
            role_id = user_obj.get("role_id", {}).get("S")
            role_obj = scan_dynamodb(tablename=USER_MGMTTABLE, 
            filter_expression = "id = :role_id AND #status = :status", 
            expression_value = {":role_id": {"S": role_id}, ":status": {"S": "active"}},
            expression_name = {"#status": "status"})
            
            if role_obj:
                return {"is_valid": True, "role_id": role_id}
                
    except Exception as e:
        print(e)
    return {"is_valid": False}


#######################################################
# Validate if the API Id is available in DynamoDB and 
# Validate role is active for the api id
#######################################################
def check_apiid_and_role(api_id, role_id):
    print(f"Api ID: {api_id}")
    print(f"Role ID: {role_id}")
    try:
        api_obj = scan_dynamodb(tablename=API_TABLE_MASTERDB, filter_expression = "api_id = :api_id AND #status = :status",
        expression_value = {":api_id": {"S": api_id}, ":status": {"S": "active"}},
        expression_name = {"#status": "status"})
        
        if api_obj:
            
            api_role_obj = scan_dynamodb(tablename=API_ROLE_TABLE, filter_expression = "role_id = :role_id AND api_id = :api_id AND #status = :status",
            expression_value = {":api_id": {"S": api_id}, ":role_id": {"S": role_id}, ":status": {"S": "active"}},
            expression_name = {"#status": "status"})
            if api_role_obj:
                return {"is_valid": True}
                
    except Exception as e:
        print(e)
    return {"is_valid": False}


class HttpVerb:
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    HEAD = "HEAD"
    DELETE = "DELETE"
    OPTIONS = "OPTIONS"
    ALL = "*"
    
    @classmethod
    def get_verb(cls, verb):
        if verb == "GET": 
            return HttpVerb.GET
        elif verb == "POST": 
            return HttpVerb.POST
        elif verb == "PUT":
            return HttpVerb.PUT
        elif verb == "PATCH": 
            return HttpVerb.PATCH
        elif verb == "HEAD":
            return HttpVerb.HEAD
        elif verb == "DELETE": 
            return HttpVerb.DELETE
        elif verb == "OPTIONS":
            return HttpVerb.OPTIONS
        elif verb == "*":
            return HttpVerb.ALL
        else:
            raise Exception("Invalid Verb")


class AuthPolicy(object):
    awsAccountId = "566692369023"
    """The AWS account id the policy will be generated for. This is used to create the method ARNs."""
    principalId = "dawerfilpe@oktaidp.com"
    """The principal used for the policy, this should be a unique identifier for the end user."""
    version = "2012-10-17"
    """The policy version used for the evaluation. This should always be '2012-10-17'"""
    pathRegex = "^[/.a-zA-Z0-9-\*]+$"
    """The regular expression used to validate resource paths for the policy"""

    """these are the internal lists of allowed and denied methods. These are lists
    of objects and each object has 2 properties: A resource ARN and a nullable
    conditions statement.
    the build method processes these lists and generates the approriate
    statements for the final policy"""
    allowMethods = []
    denyMethods = []

    restApiId = "jmdm5m8y5l"
    """ Replace the placeholder value with a default API Gateway API id to be used in the policy. 
    Beware of using '*' since it will not simply mean any API Gateway API id, because stars will greedily expand over '/' or other separators. 
    See https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements_resource.html for more details. """

    region = "us-east-1"
    """ Replace the placeholder value with a default region to be used in the policy. 
    Beware of using '*' since it will not simply mean any region, because stars will greedily expand over '/' or other separators. 
    See https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements_resource.html for more details. """

    stage = "dropdown_prod"
    """ Replace the placeholder value with a default stage to be used in the policy. 
    Beware of using '*' since it will not simply mean any stage, because stars will greedily expand over '/' or other separators. 
    See https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements_resource.html for more details. """

    def __init__(self, principal, awsAccountId):
        self.awsAccountId = awsAccountId
        self.principalId = principal
        self.allowMethods = []
        self.denyMethods = []

    def _addMethod(self, effect, verb, resource, conditions):
        """Adds a method to the internal lists of allowed or denied methods. Each object in
        the internal list contains a resource ARN and a condition statement. The condition
        statement can be null."""
        if verb != "*" and not hasattr(HttpVerb, verb):
            raise NameError(
                "Invalid HTTP verb " + verb + ". Allowed verbs in HttpVerb class"
            )
        resourcePattern = re.compile(self.pathRegex)
        if not resourcePattern.match(resource):
            raise NameError(
                "Invalid resource path: "
                + resource
                + ". Path should match "
                + self.pathRegex
            )

        if resource[:1] == "/":
            resource = resource[1:]

        resourceArn = (
            "arn:aws:execute-api:"
            + self.region
            + ":"
            + self.awsAccountId
            + ":"
            + self.restApiId
            + "/"
            + self.stage
            + "/"
            + verb
            + "/"
            + resource
        )

        if effect.lower() == "allow":
            self.allowMethods.append(
                {"resourceArn": resourceArn, "conditions": conditions}
            )
        elif effect.lower() == "deny":
            self.denyMethods.append(
                {"resourceArn": resourceArn, "conditions": conditions}
            )

    def _getEmptyStatement(self, effect):
        """Returns an empty statement object prepopulated with the correct action and the
        desired effect."""
        statement = {
            "Action": "execute-api:Invoke",
            "Effect": effect[:1].upper() + effect[1:].lower(),
            "Resource": [],
        }

        return statement

    def _getStatementForEffect(self, effect, methods):
        """This function loops over an array of objects containing a resourceArn and
        conditions statement and generates the array of statements for the policy."""
        statements = []

        if len(methods) > 0:
            statement = self._getEmptyStatement(effect)

            for curMethod in methods:
                if curMethod["conditions"] is None or len(curMethod["conditions"]) == 0:
                    statement["Resource"].append(curMethod["resourceArn"])
                else:
                    conditionalStatement = self._getEmptyStatement(effect)
                    conditionalStatement["Resource"].append(curMethod["resourceArn"])
                    conditionalStatement["Condition"] = curMethod["conditions"]
                    statements.append(conditionalStatement)

            statements.append(statement)

        return statements

    def allowAllMethods(self):
        """Adds a '*' allow to the policy to authorize access to all methods of an API"""
        self._addMethod("Allow", HttpVerb.ALL, "*", [])

    def denyAllMethods(self):
        """Adds a '*' allow to the policy to deny access to all methods of an API"""
        self._addMethod("Deny", HttpVerb.ALL, "*", [])

    def allowMethod(self, verb, resource):
        """Adds an API Gateway method (Http verb + Resource path) to the list of allowed
        methods for the policy"""
        self._addMethod("Allow", verb, resource, [])

    def denyMethod(self, verb, resource):
        """Adds an API Gateway method (Http verb + Resource path) to the list of denied
        methods for the policy"""
        self._addMethod("Deny", verb, resource, [])

    def allowMethodWithConditions(self, verb, resource, conditions):
        """Adds an API Gateway method (Http verb + Resource path) to the list of allowed
        methods and includes a condition for the policy statement. More on AWS policy
        conditions here: http://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements.html#Condition
        """
        self._addMethod("Allow", verb, resource, conditions)

    def denyMethodWithConditions(self, verb, resource, conditions):
        """Adds an API Gateway method (Http verb + Resource path) to the list of denied
        methods and includes a condition for the policy statement. More on AWS policy
        conditions here: http://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements.html#Condition
        """
        self._addMethod("Deny", verb, resource, conditions)

    def build(self):
        """Generates the policy document based on the internal lists of allowed and denied
        conditions. This will generate a policy with two main statements for the effect:
        one statement for Allow and one statement for Deny.
        Methods that includes conditions will have their own statement in the policy."""
        if (self.allowMethods is None or len(self.allowMethods) == 0) and (
            self.denyMethods is None or len(self.denyMethods) == 0
        ):
            raise NameError("No statements defined for the policy")

        policy = {
            "principalId": self.principalId,
            "policyDocument": {"Version": self.version, "Statement": []},
        }

        policy["policyDocument"]["Statement"].extend(
            self._getStatementForEffect("Allow", self.allowMethods)
        )
        policy["policyDocument"]["Statement"].extend(
            self._getStatementForEffect("Deny", self.denyMethods)
        )
        return policy
