import boto3
from boto3.dynamodb.conditions import Key, Attr
import json
from datetime import datetime
from botocore.exceptions import ClientError
from aws_lambda_powertools.tracing import Tracer
from aws_lambda_powertools import Logger
from aws_lambda_powertools.utilities.typing import LambdaContext
from aws_xray_sdk.core import patch_all
from aws_xray_sdk.core import xray_recorder

logger = Logger(service="AZURE_MASTER_DROP_DOWN", name="AZURE_MASTER_DROP_DOWN_COMPONENT")
# Patch all supported libraries for X-Ray tracing
patch_all()

tracer = Tracer()

table_name = "azure_master_data_version_2"
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(table_name)


def lambda_handler(event, context):
    try:
        # Log information about the Lambda function invocation
        logger.info("Lambda function invoked.")

        if event['httpMethod'] != 'GET':
            # Log the invalid HTTP method
            logger.warning(f"Invalid HTTP method: {event['httpMethod']}. Only GET is allowed.")
            body = {
                "statusCode": 405,
                "response": "failed",
                "error": f"Invalid HTTP method: {event['httpMethod']}. Only GET is allowed"
            }
            return build_response(405, body)
        # Perform DynamoDB scan
        response = table.scan()
        items = response['Items']
        while 'LastEvaluatedKey' in response:
            response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            items += response['Items']
        # Process and format DynamoDB scan results
        formatted_response = []
        for item in items:
            formatted_item = {
                "id": item["id"],
                "subscriptions": {
                    "value": item["subscriptions"]["subscriptionId"],
                    "resourceGroups": []
                }
            }
            for rg in item["subscriptions"]["resourceGroups"]:
                formatted_rg = {
                    "value": rg["resourceGroupNameValue"],
                    "label": rg["resourceGroupName"],
                    "regions": []
                }
                for region in rg["regions"]:
                    formatted_region = {
                        "value": region["regionValue"],
                        "label": region["regionName"],
                        "virtualNetworks": []
                    }
                    for vn in region["virtualNetworks"]:
                        formatted_vn = {
                            "label": vn["virtualNetworkName"],
                            "value": vn["virtualNetworkValue"]
                        }
                        formatted_region["virtualNetworks"].append(formatted_vn)
                    formatted_rg["regions"].append(formatted_region)
                formatted_item["subscriptions"]["resourceGroups"].append(formatted_rg)
            formatted_item["subscriptions"]["label"] = item["subscriptions"]["subscriptionName"]
            formatted_response.append(formatted_item)
        # Log information about the formatted response
        logger.info("Formatted response generated successfully.")
        body = {
            "statusCode": 200,
            "response": "success",
            "master_drop_down": formatted_response
        }
        return build_response(200, body)
    except ClientError as e:
        # Log error in case of a DynamoDB ClientError
        logger.error(f"Error getting items from DynamoDB: {e.response['Error']['Message']}")
        body = {
            "statusCode": 500,
            "response": "failed",
            "error": f"Error getting items from DynamoDB: {e.response['Error']['Message']}"
        }
        return build_response(500, body)
    except Exception as e:
        # Log error in case of an exception
        logger.error(f"Error in lambda_handler: {str(e)}")
        body = {
            "statusCode": 500,
            "response": "failed",
            "error": f"Error: {str(e)}"
        }
        return build_response(500, body)


def build_response(statusCode, body=None):
    response = {
        'statusCode': statusCode,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    }
    if body is not None:
        response['body'] = json.dumps(body)
    return response
