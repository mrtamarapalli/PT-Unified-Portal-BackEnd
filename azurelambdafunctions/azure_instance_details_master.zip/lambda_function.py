import concurrent.futures
import httpx
import json
import logging
import time
from aws_lambda_powertools import Logger
from aws_lambda_powertools.utilities.typing import LambdaContext
from aws_xray_sdk.core import patch_all
from aws_xray_sdk.core import xray_recorder
from azure.core.credentials import AccessToken
from azure.identity import DefaultAzureCredential
from azure.mgmt.compute import ComputeManagementClient
from aws_lambda_powertools.tracing import Tracer

logger = Logger(service="AZURE_INSTANCE_DETAILS_MASTER", name="AZURE_INSTANCE_DETAILS_MASTER_COMPONENT")
# Patch all supported libraries for X-Ray tracing
patch_all()

tracer = Tracer()


class StaticTokenCredential(DefaultAzureCredential):
    def __init__(self, authority=None, **kwargs):
        super().__init__(**kwargs)
        self.authority = authority

    def get_token(self, *scopes, **kwargs):
        try:
            # Log information about obtaining the static token
            logger.info("Obtaining static token.")
            # Call the get_access_token function to retrieve the token
            access_token = get_access_token()
            # Log information about the successful acquisition of the static token
            logger.info("Static token obtained successfully.")
            # Return the AccessToken object
            return AccessToken(token=access_token, expires_on=3000)
        except Exception as e:
            # Log error in case of an exception
            logger.error(f"Error in StaticTokenCredential.get_token: {str(e)}")
            # Raise the exception to be caught by the caller
            raise e


def get_access_token():
    try:
        # Log information about obtaining access token
        logger.info("Obtaining access token.")
        tenant_id = "tenant_id"
        token_url = "https://app-azure-sdk-tokens-api.azurewebsites.net/api/http_trigger"
        code_query_param = "iuXlbTHc0KAnheDD5QJTDsdoCCQlNjZlrmCEXC32XiejAzFuDmW0TA%3D%3D"
        token_url_with_code = f"{token_url}?code={code_query_param}&tenant_id={tenant_id}"
        payload = {"tenant_id": "x-key"}
        with httpx.Client() as client:
            response = client.post(token_url_with_code, json=payload)
        if response.status_code == 200:
            access_token = response.json().get('access_token')
            # Log information about the successful acquisition of the access token
            logger.info("Access token obtained successfully.")
            return access_token
        else:
            # Log error in case of a failed access token acquisition
            error_message = f"Failed to obtain access token. Status code: {response.status_code}, message: {response.text}"
            logger.error(error_message)
            raise Exception(error_message)
    except Exception as e:
        # Log error in case of an exception
        logger.error(f"Error in get_access_token: {str(e)}")
        # Raise the exception to be caught by the caller
        raise e


def lambda_handler(event, context):
    try:
        # Log information about the Lambda function invocation
        logger.info("Lambda function invoked.")
        # Check HTTP method
        if event['httpMethod'] != 'POST':
            # Log the invalid HTTP method
            logger.warning(f"Invalid HTTP method: {event['httpMethod']}. Only POST is allowed.")
            body = {
                "statusCode": 405,
                "response": "failed",
                "error": "Invalid HTTP method. Only POST is allowed"
            }
            return build_response(405, body)
        # Parse request body
        request_body = json.loads(event['body'])
        # Check required parameters in the request body
        required_parameters = ['subscriptionId', 'resource', 'cloudProvider']
        if not all(param in request_body for param in required_parameters):
            # Log missing parameters
            logger.warning(f"Missing required parameters in the request body: {', '.join(required_parameters)}")
            body = {
                "statusCode": 400,
                "response": "failed",
                "error": f"Missing {', '.join(required_parameters)} parameter(s) in the request body."
            }
            return build_response(400, body)
        # Extract parameters
        subscriptionId = request_body['subscriptionId']
        resource = request_body['resource']
        cloudProvider = request_body['cloudProvider']
        region = request_body['region']
        # Call get_drop_down_details function
        return get_drop_down_details(subscriptionId, resource, region)
    except Exception as e:
        # Log error in case of an exception
        logger.error(f"Error in lambda_handler: {str(e)}")
        # Return an error response
        return build_response(500, {"error": str(e), "response":"failed", "statusCode": 500})


def get_drop_down_details(subscription_id, resource, region):
    try:
        # Log information about the function execution
        logger.info(f"Getting drop-down details for subscription_id: {subscription_id}, "
                    f"resource: {resource}, region: {region}")
        authority_url = "https://login.microsoftonline.com/ed457c76-e1df-4656-a69e-efb6488e2b7c"  # mubashir`s account
        credential = StaticTokenCredential(authority=authority_url)
        # Use ThreadPoolExecutor for parallel execution
        with concurrent.futures.ThreadPoolExecutor() as executor:
            # Submit the tasks for parallel execution
            disk_list_future = executor.submit(get_disks, credential, subscription_id, region)
            vm_sizes_response_future = executor.submit(vm_sizes, credential, subscription_id, region)

            # Get the results from the completed tasks
            disk_list = disk_list_future.result()
            vm_sizes_response = vm_sizes_response_future.result()
        default_protocol = [{"label": "SSH (22)", "value": "SSH"},
                         {"label": "HTTP (80)", "value": "HTTP"},
                         {"label": "HTTPS (443)", "value": "HTTPS"},
                         {"label": "RDP (3389)", "value": "RDP"}]
        rules_access = [{"label": "Allow (*)", "value": "Allow"}]
        response = {
            "subscriptionId": subscription_id,
            "storageAccount": disk_list,
            "vmSizes": vm_sizes_response,
            "inbound_rules": default_protocol,
            "inbound_rules_access": rules_access,
            "outbound_rules": default_protocol,
            "out_bound_response_allow": rules_access,
            "availability_zones": [{"label": "Zone 1", "value": "1"}, {"label": "Zone 2", "value": "2"},
                                   {"label": "Zone 3", "value": "3"}],
            "create_options": [{"label": "From Image", "value": "From Image"}, {"label": "Attach", "value": "Attach"}]
        }
        # Log information about the retrieved drop-down details
        logger.info(f"Retrieved drop-down details: {response}")
        body = {
            "statusCode": 200,
            "response": "success",
            "azure_drop_down": response
        }
        return build_response(200, body)
    except Exception as e:
        # Log error in case of an exception
        logger.error(f"Error in get_drop_down_details: {str(e)}")
        # Return an error response
        body = {
            "statusCode": 400,
            "response": "failed",
            "error": str(e)
        }
        return build_response(400, body)


def build_response(status_code, body=None):
    response = {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    }
    if body is not None:
        response['body'] = json.dumps(body)
    return response


def get_disks(credential, subscription_id, region):
    try:
        # Log information about the function execution
        logger.info(f"Getting disks for subscription_id: {subscription_id}, region: {region}")
        disks = set()
        compute_client = ComputeManagementClient(credential, subscription_id)
        # Use X-Ray tracing for this specific block
        # with tracer.capture_method("get_disks_query"):
        for sku in compute_client.resource_skus.list():
            if "LRS" in sku.name or "ZRS" in sku.name:
                disks.add(str(sku.name))

        disk_list = [{"value": _, "label": _} for _ in disks]
        # Log information about the retrieved disks
        logger.info(f"Retrieved disks: {disk_list}")
        return disk_list
    except Exception as e:
        # Log error in case of an exception
        logger.error(f"Error in get_disks: {str(e)}")
        # Return an empty list in case of an error
        return []


def vm_sizes(credential, subscription_id, region):
    try:
        # Log information about the function execution
        logger.info(f"Fetching VM sizes for subscription_id: {subscription_id}, region: {region}")
        compute_client = ComputeManagementClient(credential, subscription_id)
        # Use X-Ray tracing for this specific block
        # with tracer.capture_method("vm_sizes_query"):
        vm_sizes_response = [
            {
                "label": f"{size.name}-{size.number_of_cores} vcpu, {size.memory_in_mb / 1024} Gb memory",
                "value": size.name,
            }
            for size in compute_client.virtual_machine_sizes.list(region)
        ]
        # Log information about the retrieved VM sizes
        logger.info(f"Retrieved VM sizes: {vm_sizes_response}")
    except Exception as e:
        # Log error in case of an exception
        logger.error(f"Error in vm_sizes: {str(e)}")
        # Return an empty list in case of an error
        vm_sizes_response = []
    return vm_sizes_response

# 
# if __name__ == "__main__":
#     event = {
#         'httpMethod': 'POST',
#         'body': json.dumps({
#             "subscriptionId": "1a98945d-330d-45a0-99c3-e592616c3a8e",
#             "resource": "test-for-carbynetech",
#             "cloudProvider": "azure",
#             "region": "eastus",
#         })
#     }
#     context = None
#     result = lambda_handler(event, context)
#     print(result)
