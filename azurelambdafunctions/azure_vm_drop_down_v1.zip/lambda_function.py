import boto3, httpx
from boto3.dynamodb.conditions import Attr
import json
from botocore.exceptions import ClientError
from azure.identity import DefaultAzureCredential
from azure.mgmt.compute import ComputeManagementClient
from aws_lambda_powertools.tracing import Tracer
from aws_lambda_powertools import Logger
from azure.core.credentials import AccessToken
from aws_lambda_powertools.utilities.typing import LambdaContext
from aws_xray_sdk.core import patch_all
from aws_xray_sdk.core import xray_recorder

logger = Logger(service="AZURE_INSTANCE_START_STOP", name="AZURE_INSTANCE_START_STOP_COMPONENT")
# Patch all supported libraries for X-Ray tracing
patch_all()

tracer = Tracer()


class StaticTokenCredential(DefaultAzureCredential):
    def __init__(self, authority=None, **kwargs):
        super().__init__(**kwargs)
        self.authority = authority

    def get_token(self, *scopes, **kwargs):
        try:
            # Log information about obtaining the static token
            logger.info("Obtaining static token.")
            # Call the get_access_token function to retrieve the token
            access_token = get_access_token()
            # Log information about the successful acquisition of the static token
            logger.info("Static token obtained successfully.")
            # Return the AccessToken object
            return AccessToken(token=access_token, expires_on=3000)
        except Exception as e:
            # Log error in case of an exception
            logger.error(f"Error in StaticTokenCredential.get_token: {str(e)}")
            # Raise the exception to be caught by the caller
            raise e


def get_access_token():
    try:
        # Log information about obtaining access token
        logger.info("Obtaining access token.")
        tenant_id = "tenant_id"
        token_url = "https://app-azure-sdk-tokens-api.azurewebsites.net/api/http_trigger"
        code_query_param = "iuXlbTHc0KAnheDD5QJTDsdoCCQlNjZlrmCEXC32XiejAzFuDmW0TA%3D%3D"
        token_url_with_code = f"{token_url}?code={code_query_param}&tenant_id={tenant_id}"
        payload = {"tenant_id": "x-key"}
        with httpx.Client() as client:
            response = client.post(token_url_with_code, json=payload)
        if response.status_code == 200:
            access_token = response.json().get('access_token')
            # Log information about the successful acquisition of the access token
            logger.info("Access token obtained successfully.")
            return access_token
        else:
            # Log error in case of a failed access token acquisition
            error_message = f"Failed to obtain access token. Status code: {response.status_code}, message: {response.text}"
            logger.error(error_message)
            raise Exception(error_message)
    except Exception as e:
        # Log error in case of an exception
        logger.error(f"Error in get_access_token: {str(e)}")
        # Raise the exception to be caught by the caller
        raise e


def lambda_handler(event, context):
    try:
        # Log information about the Lambda function invocation
        logger.info("Lambda function invoked.")

        # Check if the event contains the required parameters
        if event['httpMethod'] != 'POST':
            # Log the invalid HTTP method
            logger.warning(f"Invalid HTTP method: {event['httpMethod']}. Only POST is allowed.")
            body = {
                "statusCode": 405,
                "response": "failed",
                "error": "Invalid HTTP method. Only POST is allowed"
            }
            return build_response(405, body)

        # Parse the JSON body of the POST request
        request_body = json.loads(event['body'])
        subscriptionId = request_body['subscriptionId']
        resourceGroup = request_body['resourceGroup']
        region = request_body['region']
        virtualNetwork = request_body.get('virtualNetwork')  # Make virtualNetwork optional

        # Log information about the received parameters
        logger.info(f"Received parameters: subscriptionId={subscriptionId}, resourceGroup={resourceGroup}, "
                    f"region={region}, virtualNetwork={virtualNetwork}")

        # Validate the action
        if subscriptionId is None or resourceGroup is None or region is None:
            # Log invalid action
            logger.warning("Invalid action. Required payload "
                           '{"subscriptionId":"xxxxxx","resourceGroup":"xxxxxx","region":"xxxxxx","virtualNetwork":"xxxxxx"}.')
            body = {
                "statusCode": 400,
                "response": "failed",
                "error": 'Invalid action. Required payload '
                         '{"subscriptionId":"xxxxxx","resourceGroup":"xxxxxx","region":"xxxxxx","virtualNetwork":"xxxxxx"}.'
            }
            return build_response(400, body)

        # Determine the DynamoDB table based on a key in the request
        table_name = (
            "instance_genpact_azure_01"
            if 'resourceName' in request_body and request_body['resourceName'].lower() == 'vm'
            else "azure_storage_account"
            if 'resourceName' in request_body and request_body['resourceName'].lower() == 'storage'
            else "azure_sql_account_details"
        )

        # Log information about the selected DynamoDB table
        logger.info(f"Selected DynamoDB table: {table_name}")

        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(table_name)

        # Define attribute mapping based on the table
        attribute_mapping = {
            "instance_genpact_azure_01": {
                'subscriptionId_attr': 'subscriptionId',
                'resourceGroup_attr': 'Resourcegroup',
                'region_attr': 'Region',
                'virtualNetwork_attr': 'virtualNetwork'
            },
            "azure_sql_account_details": {
                'subscriptionId_attr': 'subscriptionId',
                'resourceGroup_attr': 'Resourcegroup',
                'region_attr': 'Region',
                'virtualNetwork_attr': 'virtualNetwork'
            },
            "azure_storage_account": {
                'subscriptionId_attr': 'subscriptionId',
                'resourceGroup_attr': 'Resourcegroup',
                'region_attr': 'Region',
                'virtualNetwork_attr': 'virtualNetwork'
            }
        }

        # Get attribute names based on the table
        subscriptionId_attr = attribute_mapping[table_name]['subscriptionId_attr']
        resourceGroup_attr = attribute_mapping[table_name]['resourceGroup_attr']
        region_attr = attribute_mapping[table_name]['region_attr']
        virtualNetwork_attr = attribute_mapping[table_name]['virtualNetwork_attr']

        response = table.scan(
            FilterExpression=Attr(subscriptionId_attr).eq(subscriptionId) &
                             Attr(resourceGroup_attr).eq(resourceGroup) &
                             Attr(region_attr).eq(region)
            # & Attr(virtualNetwork_attr).eq(virtualNetwork)
        )
        items = response.get('Items', [])

        # Log information about the DynamoDB scan results
        logger.info(f"DynamoDB scan results: {items}")

        if not items:
            # Log data not found
            logger.warning(f"Data not found with subscriptionId: {subscriptionId}, "
                           f"resourceGroup: {resourceGroup}, region: {region}, and virtualNetwork: {virtualNetwork}")
            body = {
                "statusCode": 400,
                "response": "failed",
                "error": f"Data not found with subscriptionId: {subscriptionId}, "
                         f"resourceGroup: {resourceGroup}, region: {region}, and virtualNetwork: {virtualNetwork}"
            }
            return build_response(400, body)

        # Remove 'virtualNetwork' field if 'resourceName' is 'sql' and 'storage'
        if 'resourceName' in request_body and (request_body['resourceName'].lower() == 'sql' or
                                               request_body['resourceName'].lower() == 'storage'):
            for item in items:
                item.pop(virtualNetwork_attr, None)
        if 'resourceName' in request_body and request_body['resourceName'].lower() == 'vm':
            for item in items:
                status = item.get("status", "").lower()
                logger.info(status)
                if status == "completed":
                    # Log information about checking the live status of VM
                    logger.info(f"Checking live status of VM '{item['VMName']}'.")

                    # Call the function to get live status from Azure
                    item['StatusCheck'] = getLiveStatusFromAzure(subscriptionId, resourceGroup, virtualNetwork,
                                                                 item['VMName'])
        logger.info("Formatted response generated successfully.")
        body = {
            "statusCode": 200,
            "response": "success",
            "tabel_details": items
        }
        return build_response(200, body)
    except ClientError as e:
        logger.error(f"Error getting items from DynamoDB: {e.response['Error']['Message']}")
        body = {
            "statusCode": 500,
            "response": "failed",
            "error": f"Error getting items from DynamoDB: {e.response['Error']['Message']}"
        }
        return build_response(500, body)
    except Exception as ex:
        logger.error(f"Error in lambda_handler: {str(ex)}")
        body = {
            "statusCode": 500,
            "response": "failed",
            "error": f"Error in lambda_handler: {str(ex)}"
        }
        return build_response(500, body)


def getLiveStatusFromAzure(subscriptionId, resourceGroup, virtualNetwork, vmName):
    try:
        # Log information about the Azure status check
        logger.info(f"Checking live status of VM '{vmName}' in subscription '{subscriptionId}', "
                    f"resource group '{resourceGroup}', virtual network '{virtualNetwork}'.")
        # Set the authority URL for Azure AD authentication
        authority_url = "https://login.microsoftonline.com/ed457c76-e1df-4656-a69e-efb6488e2b7c"
        # Use StaticTokenCredential for authentication
        credentials = StaticTokenCredential(authority=authority_url)
        # Create a Compute Management client
        compute_client = ComputeManagementClient(credentials, subscriptionId)
        # Get the VM instance
        vm_instance = compute_client.virtual_machines.get(resourceGroup, vmName)
        # Get the VM status
        vm_status = vm_instance.instance_view.statuses[1].display_status
        # Log the retrieved VM status
        logger.info(f"Live status of VM '{vmName}' is '{vm_status}'.")
        return vm_status
    except Exception as e:
        # Log error in case of an exception
        logger.error(f"Error in getLiveStatusFromAzure: {str(e)}")
        # Return a default status or handle the error as needed
        return "Something went wrong"


def build_response(statusCode, body=None):
    response = {
        'statusCode': statusCode,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    }
    if body is not None:
        response['body'] = json.dumps(body)
    return response
