import json
import httpx
from azure.identity import DefaultAzureCredential
from azure.mgmt.compute import ComputeManagementClient
from azure.core.credentials import AccessToken
from azure.core.credentials import AccessToken
from aws_lambda_powertools.tracing import Tracer
from aws_lambda_powertools import Logger
from aws_lambda_powertools.utilities.typing import LambdaContext
from aws_xray_sdk.core import patch_all
from aws_xray_sdk.core import xray_recorder

logger = Logger(service="AZURE_INSTANCE_START_STOP", name="AZURE_INSTANCE_START_STOP_COMPONENT")
# Patch all supported libraries for X-Ray tracing
patch_all()

tracer = Tracer()


class StaticTokenCredential(DefaultAzureCredential):
    def __init__(self, authority=None, **kwargs):
        super().__init__(**kwargs)
        self.authority = authority

    def get_token(self, *scopes, **kwargs):
        try:
            # Log information about obtaining the static token
            logger.info("Obtaining static token.")
            # Call the get_access_token function to retrieve the token
            access_token = get_access_token()
            # Log information about the successful acquisition of the static token
            logger.info("Static token obtained successfully.")
            # Return the AccessToken object
            return AccessToken(token=access_token, expires_on=3000)
        except Exception as e:
            # Log error in case of an exception
            logger.error(f"Error in StaticTokenCredential.get_token: {str(e)}")
            # Raise the exception to be caught by the caller
            raise e


def get_access_token():
    try:
        # Log information about obtaining access token
        logger.info("Obtaining access token.")
        tenant_id = "tenant_id"
        token_url = "https://app-azure-sdk-tokens-api.azurewebsites.net/api/http_trigger"
        code_query_param = "iuXlbTHc0KAnheDD5QJTDsdoCCQlNjZlrmCEXC32XiejAzFuDmW0TA%3D%3D"
        token_url_with_code = f"{token_url}?code={code_query_param}&tenant_id={tenant_id}"
        payload = {"tenant_id": "x-key"}
        with httpx.Client() as client:
            response = client.post(token_url_with_code, json=payload)
        if response.status_code == 200:
            access_token = response.json().get('access_token')
            # Log information about the successful acquisition of the access token
            logger.info("Access token obtained successfully.")
            return access_token
        else:
            # Log error in case of a failed access token acquisition
            error_message = f"Failed to obtain access token. Status code: {response.status_code}, message: {response.text}"
            logger.error(error_message)
            raise Exception(error_message)
    except Exception as e:
        # Log error in case of an exception
        logger.error(f"Error in get_access_token: {str(e)}")
        # Raise the exception to be caught by the caller
        raise e


def get_azure_vm_manager(subscription_id, resource_group_name, vm_name):
    # Use the correct authority URL for your Azure AD tenant
    authority_url = "https://login.microsoftonline.com/ed457c76-e1df-4656-a69e-efb6488e2b7c"
    # Explicitly specify the token in StaticTokenCredential
    credential = StaticTokenCredential(authority=authority_url)
    compute_client = ComputeManagementClient(credential, subscription_id)

    def try_except_wrapper(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                # Log error and re-raise the exception
                logger.error(f"Error: {str(e)}")
                raise e

        return wrapper

    @try_except_wrapper
    def start_vm():
        return compute_client.virtual_machines.begin_start(resource_group_name, vm_name)

    @try_except_wrapper
    def stop_vm():
        return compute_client.virtual_machines.begin_power_off(resource_group_name, vm_name)

    @try_except_wrapper
    def get_operation_status(operation_result):
        try:
            operation_result.result()
            status_message = f"Operation succeeded. VM '{vm_name}' is now {operation_result.status().lower()}."
            # Log success message
            logger.info(status_message)
            return status_message
        except Exception as e:
            # Log error and return failure message
            logger.error(f"Error: {str(e)}")
            body = {
                "statusCode": 400,
                "response": "failed",
                "error": f"Operation failed. Unable to perform operation on VM '{vm_name}'."
            }
            return build_response(400, body)

    return start_vm, stop_vm, get_operation_status


def build_response(status_code, body=None):
    response = {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    }
    if body is not None:
        response['body'] = json.dumps(body)
    return response


def lambda_handler(event, context):
    try:
        # Log information about the Lambda function invocation
        logger.info("Lambda function invoked.")
        if event['httpMethod'] != 'POST':
            # Log the invalid HTTP method
            logger.warning(f"Invalid HTTP method: {event['httpMethod']}. Only POST is allowed.")
            body = {
                "statusCode": 405,
                "response": "failed",
                "error": f"Invalid HTTP method: {event['httpMethod']}. Only POST is allowed."
            }
            return build_response(405, body)
        body = json.loads(event['body'])
        subscription_id = body.get('subscription_id')
        resource_group_name = body.get('resource_group_name')
        vm_name = body.get('vm_name')
        action = body.get('action')
        if not all([subscription_id, resource_group_name, vm_name, action]):
            # Log missing parameters
            logger.warning("Missing required parameters in the request body.")
            body = {
                "statusCode": 400,
                "response": "failed",
                "error": json.dumps('Missing required parameters.')
            }
            return build_response(400, body)

        # Log information about the parameters received
        logger.info(f"Received parameters: subscription_id={subscription_id}, "
                    f"resource_group_name={resource_group_name}, vm_name={vm_name}, action={action}")
        start_vm, stop_vm, get_operation_status = get_azure_vm_manager(
            subscription_id, resource_group_name, vm_name
        )
        if action == 'start':
            result = start_vm()
        elif action == 'stop':
            result = stop_vm()
        else:
            # Log invalid action
            logger.warning(f"Invalid action: {action}. Use 'start' or 'stop'.")
            body = {
                "statusCode": 400,
                "response": "failed",
                "error": json.dumps(f"Invalid action: {action}. Use 'start' or 'stop'.")
            }
            return build_response(400, body)
        # Log information about the operation result
        logger.info(f"Operation result: {get_operation_status(result)}")
        body = {
            "statusCode": 200,
            "response": "success",
            "vm_status": json.dumps(get_operation_status(result))
        }
        return build_response(200, body)
    except json.JSONDecodeError:
        # Log invalid JSON format in the request body
        logger.error("Invalid JSON format in the request body.")
        body = {
            "statusCode": 400,
            "response": "failed",
            "error": json.dumps('Invalid JSON format in the request body.')
        }
        return build_response(400, body)

    except Exception as e:
        # Log error in case of an exception
        logger.error(f"Error in lambda_handler: {str(e)}")
        body = {
            "statusCode": 500,
            "response": "failed",
            "error": json.dumps(f'Error: {str(e)}')
        }
        return build_response(500, body)

# 
# if __name__ == "__main__":
#     event = {
#         'httpMethod': 'POST',
#         'body': json.dumps({
#             "subscription_id": "1a98945d-330d-45a0-99c3-e592616c3a8e",
#             "vm_name": "test-carbynetech",
#             "resource_group_name": "test-for-carbynetech",
#             "action": "start"
#         })
#     }
#     context = None
#     result = lambda_handler(event, context)
#     print(result)